# 83f2-907-79b1-a4a.host-ai.site

Архив исходного кода сайта, сгенерированного на платформе ХостAI.

## Архитектура

- **Nginx** — устанавливается на хост-машину, обслуживает фронтенд и проксирует запросы к backend
- **Backend** — запускается в Docker-контейнере (порт 8080)

## Требования

- Linux-сервер (Ubuntu/Debian или CentOS/RHEL/Fedora)
- Домен, направленный A-записью на IP сервера
- Права sudo
- [Docker](https://docs.docker.com/get-docker/) (скрипт установит автоматически)

## Быстрый запуск

### Вариант 1: автоматический (рекомендуется)

```bash
chmod +x install.sh
./install.sh
```

Скрипт интерактивный — он спросит у вас:
1. **Домен сайта** (убедитесь, что A-запись уже направлена на сервер)
2. **Нужен ли SSL-сертификат** (Let's Encrypt через Certbot)

Что скрипт сделает автоматически:
- Установит Nginx, Docker и Certbot (если не установлены)
- Скопирует файлы фронтенда в `/var/www/83f2-907-79b1-a4a.host-ai.site/`
- Настроит Nginx для вашего домена
- Запустит backend и БД в Docker
- Выпустит SSL-сертификат (по желанию)

### Вариант 2: ручной

1. Установите Nginx:
```bash
sudo apt install nginx    # Ubuntu/Debian
sudo dnf install nginx    # CentOS/Fedora
```

2. Скопируйте фронтенд:
```bash
sudo mkdir -p /var/www/83f2-907-79b1-a4a.host-ai.site
sudo cp -r frontend/ /var/www/83f2-907-79b1-a4a.host-ai.site/frontend/
sudo cp -r assets/ /var/www/83f2-907-79b1-a4a.host-ai.site/assets/
```

3. Скопируйте и настройте конфиг Nginx:
```bash
sudo cp nginx.conf /etc/nginx/sites-available/ВАШ_ДОМЕН
# Замените __DOMAIN__ на ваш домен и __SITE_DIR__ на /var/www/83f2-907-79b1-a4a.host-ai.site
sudo sed -i 's|__DOMAIN__|ВАШ_ДОМЕН|g' /etc/nginx/sites-available/ВАШ_ДОМЕН
sudo sed -i 's|__SITE_DIR__|/var/www/83f2-907-79b1-a4a.host-ai.site|g' /etc/nginx/sites-available/ВАШ_ДОМЕН
sudo ln -s /etc/nginx/sites-available/ВАШ_ДОМЕН /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

4. Запустите Docker-сервисы:
```bash
docker compose up -d
```

5. Выпустите SSL:
```bash
sudo certbot --nginx -d ВАШ_ДОМЕН
```

## Структура архива

```
83f2-907-79b1-a4a.host-ai.site/
├── frontend/                # Файлы фронтенда (HTML, CSS, JS)
├── assets/                  # Медиа-файлы и ассеты
├── backend/                 # Бинарник бекенда + конфигурация
├── frontend_backup/         # Резервная копия фронтенда (backup.zip)
├── backend_backup/          # Резервная копия бекенда (backup.zip)
├── docker-compose.yml       # Docker Compose (backend + БД)
├── nginx.conf               # Конфигурация Nginx (шаблон для хоста)
├── install.sh               # Интерактивный скрипт установки
└── README.md                # Эта инструкция
```

## Управление

### Docker-сервисы

```bash
# Статус
docker compose ps

# Логи
docker compose logs -f

# Перезапуск
docker compose restart

# Остановка
docker compose down

# Остановка с удалением данных БД
docker compose down -v
```

### Nginx

```bash
# Проверка конфигурации
sudo nginx -t

# Перезагрузка
sudo systemctl reload nginx

# Статус
sudo systemctl status nginx
```

### SSL-сертификат

Certbot автоматически настраивает cron-задачу для обновления сертификата. Ручное обновление:

```bash
sudo certbot renew
```

---

Сгенерировано на платформе [ХостAI](https://host-ai.site)
