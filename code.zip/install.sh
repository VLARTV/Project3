#!/bin/bash
set -e

# ============================================================
# Интерактивный скрипт установки сайта "83f2-907-79b1-a4a.host-ai.site"
#
# Что делает:
#   1. Спрашивает домен сайта
#   2. Устанавливает Nginx, Docker, Certbot (если нет)
#   3. Копирует файлы фронтенда на сервер
#   4. Настраивает Nginx для домена
#   5. Запускает backend и БД в Docker
#   6. Выпускает SSL-сертификат через Certbot
#
# Поддерживаемые ОС: Ubuntu/Debian, CentOS/RHEL/Fedora
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "\n${CYAN}=== $1 ===${NC}\n"; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SITE_DIR="/var/www/83f2-907-79b1-a4a.host-ai.site"

# -------------------------------------------------------
# 1. Интерактивный ввод домена
# -------------------------------------------------------
ask_domain() {
    log_step "Настройка домена"

    echo -e "${YELLOW}ВНИМАНИЕ:${NC} Перед продолжением убедитесь, что:"
    echo "  1. У вас есть домен"
    echo "  2. A-запись домена направлена на IP этого сервера"
    echo "  3. DNS-записи уже распространились (может занять до 24 часов)"
    echo ""

    while true; do
        read -rp "Введите домен сайта (например, example.com): " DOMAIN
        DOMAIN=$(echo "$DOMAIN" | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')

        if [[ -z "$DOMAIN" ]]; then
            log_error "Домен не может быть пустым."
            continue
        fi

        # Простая валидация формата
        if [[ ! "$DOMAIN" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
            log_error "Некорректный формат домена. Попробуйте снова."
            continue
        fi

        echo ""
        read -rp "Вы указали домен: ${DOMAIN}. Верно? (y/n): " CONFIRM
        if [[ "$CONFIRM" =~ ^[Yy]$ ]]; then
            break
        fi
    done

    log_info "Домен: ${DOMAIN}"
}

# -------------------------------------------------------
# 2. Определение пакетного менеджера
# -------------------------------------------------------
detect_pkg_manager() {
    if command -v apt-get &> /dev/null; then
        PKG_MANAGER="apt"
    elif command -v dnf &> /dev/null; then
        PKG_MANAGER="dnf"
    elif command -v yum &> /dev/null; then
        PKG_MANAGER="yum"
    else
        log_error "Не удалось определить пакетный менеджер. Поддерживаются: apt, dnf, yum."
        exit 1
    fi
}

pkg_install() {
    case "$PKG_MANAGER" in
        apt) sudo apt-get update -qq && sudo apt-get install -y -qq "$@" ;;
        dnf) sudo dnf install -y -q "$@" ;;
        yum) sudo yum install -y -q "$@" ;;
    esac
}

# -------------------------------------------------------
# 3. Установка Nginx
# -------------------------------------------------------
install_nginx() {
    log_step "Nginx"

    if command -v nginx &> /dev/null; then
        log_info "Nginx уже установлен: $(nginx -v 2>&1)"
        return 0
    fi

    log_warn "Nginx не найден. Устанавливаю..."
    pkg_install nginx

    sudo systemctl enable nginx
    sudo systemctl start nginx
    log_info "Nginx установлен и запущен."
}

# -------------------------------------------------------
# 4. Установка Docker
# -------------------------------------------------------
install_docker() {
    log_step "Docker"

    if command -v docker &> /dev/null; then
        log_info "Docker уже установлен: $(docker --version)"
    else
        log_warn "Docker не найден. Устанавливаю..."
        curl -fsSL https://get.docker.com | sh
        sudo systemctl enable docker
        sudo systemctl start docker
        sudo usermod -aG docker "$USER"
        log_info "Docker установлен."
    fi

    # Проверяем Docker Compose
    if docker compose version &> /dev/null; then
        COMPOSE_CMD="docker compose"
        log_info "Docker Compose (plugin): $(docker compose version)"
    elif command -v docker-compose &> /dev/null; then
        COMPOSE_CMD="docker-compose"
        log_info "Docker Compose (standalone): $(docker-compose --version)"
    else
        log_error "Docker Compose не найден. Установите docker-compose-plugin."
        exit 1
    fi
}

# -------------------------------------------------------
# 5. Установка Certbot
# -------------------------------------------------------
install_certbot() {
    log_step "Certbot (SSL)"

    if command -v certbot &> /dev/null; then
        log_info "Certbot уже установлен: $(certbot --version 2>&1)"
        return 0
    fi

    log_warn "Certbot не найден. Устанавливаю..."
    case "$PKG_MANAGER" in
        apt)
            pkg_install certbot python3-certbot-nginx
            ;;
        dnf|yum)
            pkg_install certbot python3-certbot-nginx
            ;;
    esac
    log_info "Certbot установлен."
}

# -------------------------------------------------------
# 6. Копирование файлов сайта
# -------------------------------------------------------
deploy_files() {
    log_step "Размещение файлов"

    sudo mkdir -p "$SITE_DIR"

    # Frontend
    if [[ -d "$SCRIPT_DIR/frontend" ]]; then
        sudo cp -r "$SCRIPT_DIR/frontend" "$SITE_DIR/frontend"
        log_info "Frontend скопирован в $SITE_DIR/frontend"
    fi

    # Assets
    if [[ -d "$SCRIPT_DIR/assets" ]]; then
        sudo cp -r "$SCRIPT_DIR/assets" "$SITE_DIR/assets"
        log_info "Assets скопированы в $SITE_DIR/assets"
    fi

    # Backend (остаётся на месте — запускается через Docker)
    log_info "Backend будет запущен из $SCRIPT_DIR/backend через Docker"
}

# -------------------------------------------------------
# 7. Настройка Nginx
# -------------------------------------------------------
configure_nginx() {
    log_step "Конфигурация Nginx"

    local NGINX_CONF="/etc/nginx/sites-available/${DOMAIN}"
    local NGINX_ENABLED="/etc/nginx/sites-enabled/${DOMAIN}"

    # Создаём sites-available/sites-enabled если отсутствуют (CentOS)
    sudo mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled

    # Проверяем, что в nginx.conf подключены sites-enabled
    if ! grep -q "sites-enabled" /etc/nginx/conf.d/../nginx.conf 2>/dev/null; then
        if [[ -f /etc/nginx/nginx.conf ]] && ! grep -q "include.*sites-enabled" /etc/nginx/nginx.conf; then
            # Добавляем include в http-блок
            sudo sed -i '/http {/a \    include /etc/nginx/sites-enabled/*;' /etc/nginx/nginx.conf 2>/dev/null || true
        fi
    fi

    # Копируем шаблон и подставляем значения
    sudo cp "$SCRIPT_DIR/nginx.conf" "$NGINX_CONF"
    sudo sed -i "s|__DOMAIN__|${DOMAIN}|g" "$NGINX_CONF"
    sudo sed -i "s|__SITE_DIR__|${SITE_DIR}|g" "$NGINX_CONF"

    # Активируем сайт
    sudo ln -sf "$NGINX_CONF" "$NGINX_ENABLED"

    # Удаляем default-конфиг если мешает
    if [[ -f /etc/nginx/sites-enabled/default ]]; then
        sudo rm -f /etc/nginx/sites-enabled/default
    fi

    # Проверяем конфигурацию
    if sudo nginx -t 2>&1; then
        sudo systemctl reload nginx
        log_info "Nginx настроен для домена ${DOMAIN}"
    else
        log_error "Ошибка конфигурации Nginx! Проверьте $NGINX_CONF"
        exit 1
    fi
}

# -------------------------------------------------------
# 8. Запуск Docker-сервисов
# -------------------------------------------------------
start_docker_services() {
    log_step "Запуск Docker-сервисов"

    cd "$SCRIPT_DIR"
    $COMPOSE_CMD up -d

    log_info "Docker-сервисы запущены."
    log_info "Backend: 127.0.0.1:8080"
}

# -------------------------------------------------------
# 9. Выпуск SSL-сертификата
# -------------------------------------------------------
setup_ssl() {
    log_step "SSL-сертификат"

    echo ""
    read -rp "Выпустить SSL-сертификат через Let's Encrypt? (y/n): " SETUP_SSL

    if [[ ! "$SETUP_SSL" =~ ^[Yy]$ ]]; then
        log_warn "SSL пропущен. Сайт доступен по HTTP: http://${DOMAIN}"
        return 0
    fi

    read -rp "Введите email для Let's Encrypt (для уведомлений об истечении): " LE_EMAIL

    if [[ -z "$LE_EMAIL" ]]; then
        log_warn "Email не указан, используем --register-unsafely-without-email"
        sudo certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email
    else
        sudo certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$LE_EMAIL"
    fi

    log_info "SSL-сертификат выпущен. Сайт доступен по HTTPS: https://${DOMAIN}"
}

# -------------------------------------------------------
# Главная функция
# -------------------------------------------------------
main() {
    echo ""
    echo "========================================"
    echo "  Установка сайта \"83f2-907-79b1-a4a.host-ai.site\""
    echo "========================================"
    echo ""

    # Проверяем root/sudo
    if [[ "$EUID" -ne 0 ]] && ! sudo -n true 2>/dev/null; then
        log_warn "Скрипт требует sudo-прав для установки пакетов и настройки Nginx."
    fi

    ask_domain
    detect_pkg_manager
    install_nginx
    install_docker
    install_certbot
    deploy_files
    configure_nginx
    start_docker_services
    setup_ssl

    log_step "Готово!"
    log_info "Сайт установлен и доступен по адресу: http://${DOMAIN}"
    log_info "Docker-сервисы: cd $SCRIPT_DIR && $COMPOSE_CMD ps"
    log_info "Конфигурация Nginx: /etc/nginx/sites-available/${DOMAIN}"
    echo ""
}

main
